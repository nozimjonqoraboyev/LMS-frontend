export const token_name="java_g2_key"
export const token_expired=1000*60*60;