import {HttpRequestHub} from "../HttpRequestHub";

export const userInfo=()=>{
    const config={
        url:'/admin/get-user-info',
        method:'GET',
    }
    return HttpRequestHub(config);
}