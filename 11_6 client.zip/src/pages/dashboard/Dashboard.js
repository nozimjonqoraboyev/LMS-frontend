import React from "react";
import {userInfo} from "../../server/config/User";

class Dashboard extends React.Component{
    state={
        user:null
    }

    getUserInfo=()=>{
        userInfo().then(res=>{
            if (res && res.data){
                let dto=res.data;
               this.setState({
                   user:dto.data
               })
            }
        })
    }

    componentDidMount() {
        this.getUserInfo();
    }

    render() {
        const{user}=this.state;
        return(
            <React.Fragment>
           <h1>Fullname : {user?.fullname} </h1>
           <h1>Username :  {user?.username}</h1>
            </React.Fragment>
        )
    }
}export default Dashboard;